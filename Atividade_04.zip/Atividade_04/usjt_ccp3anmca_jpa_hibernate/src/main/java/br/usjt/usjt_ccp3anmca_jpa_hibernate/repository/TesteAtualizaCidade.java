package br.usjt.usjt_ccp3anmca_jpa_hibernate.repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import br.usjt.usjt_ccp3anmca_jpa_hibernate.model.Usuario;

public class TesteAtualizaCidade {

	public static void main(String[] args) {
		EntityManager manager = JPAUtil.getEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		Cidade u = manager.find(Cidade.class, 1L);
		u.setNome(u.getNome()+" da Silva");
		u.setLatitude("987645412");
		u.setLongitude("1234563");
		transaction.commit();
		manager.close();
		JPAUtil.close();
	}

}
