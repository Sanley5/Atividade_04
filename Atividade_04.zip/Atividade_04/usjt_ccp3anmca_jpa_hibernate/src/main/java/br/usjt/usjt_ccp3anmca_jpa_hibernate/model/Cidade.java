package br.usjt.usjt_ccp3anmca_jpa_hibernate.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="tb_cidade")
public class Cidade {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(nullable=false,length=200)
	private String nome;
	@Column(nullable=false,length=30)
	private Double latitude;
	@Column(nullable=false,length=100)
	private Double longitude;
	@OneToOne(optional=false, cascade=CascadeType.ALL)
	@JoinColumn(name="id_do_meu_tempos")
	private Tempos tempos;
	//@ManyToMany(cascade=CascadeType.ALL)
	//@JoinTable(name="tb_usuario_conteudo",
	//	joinColumns=@JoinColumn(name="id_usuario"), 
	//	inverseJoinColumns=@JoinColumn(name="id_conteudo"))
	//private List<Conteudo> conteudos;
	@OneToMany (mappedBy = "cidade", cascade=CascadeType.ALL)
	private List <DiasDaSemana> diasDaSemana;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public Tempos getTempos() {
		return tempos;
	}
	public void setTempos(Tempos tempos) {
		this.tempos = tempos;
	}
	public List<DiasDaSemana> getDiasDaSemana() {
		return diasDaSemana;
	}
	public void setDiasDaSemana(List<DiasDaSemana> diasDaSemana) {
		this.diasDaSemana = diasDaSemana;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Cidade [id=" + id + ", nome=" + nome + ", latitude=" + latitude + ", longitude=" + longitude + ", Previs�o do tempo=" + tempos
				+ "]";
	}

}
