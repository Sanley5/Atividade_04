package br.usjt.hellospringboot.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Tempos implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private String semana, textCamp;
	private int tempMin, tempMax, umidade;
	@JoinColumn(name="id_do_minha_cidade")
	private Cidade Cidade;
	
	public Strinh getSemana() {
		return semana;
	}
	public void setSemana(String semana) {
		this.semana = semana;
	}
	public String getTextCamp() {
		return textCamp;
	}
	public void setTextCamp(String textCamp) {
		this.textCamp = textCamp;
	}
	public int getTempMin () {
		return tempMin;
	}
	public void setTempMin (int tempMin) {
		this.tempMin = tempMin;
	}
	public int getTempMax () {
		return tempMax;
	}
	public void setTempMax(int tempMax){
		this.tempMax = tempMax;
	}
	public int getUmidade() {
		return Umidade;
	}
	public void setUmidade (int umidade) {
		this.umidade = umidade;
	}
	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}
}
